const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const { name, email } = JSON.parse(event.body);
  const params = {
    TableName: "server_db",
    Item: { id: email, name, email },
  };
  await dynamo.put(params).promise();
  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*", // Or specify your domain instead of *
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST,OPTIONS",
    },
    body: JSON.stringify({ message: "Data saved successfully" }),
  };
};
